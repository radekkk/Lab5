angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('homepage', {
    url: '/page2',
    templateUrl: 'templates/homepage.html',
    controller: 'homepageCtrl'
  })

  .state('wydziaY', {
    url: '/page3',
    templateUrl: 'templates/wydziaY.html',
    controller: 'wydziaYCtrl'
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('pytanie1', {
    url: '/page5',
    templateUrl: 'templates/pytanie1.html',
    controller: 'pytanie1Ctrl'
  })

  .state('quiz', {
    url: '/page6',
    templateUrl: 'templates/quiz.html',
    controller: 'quizCtrl'
  })

  .state('pytanie2', {
    url: '/page7',
    templateUrl: 'templates/pytanie2.html',
    controller: 'pytanie2Ctrl'
  })

  .state('pytanie3', {
    url: '/page8',
    templateUrl: 'templates/pytanie3.html',
    controller: 'pytanie3Ctrl'
  })

  .state('pytanie4', {
    url: '/page9',
    templateUrl: 'templates/pytanie4.html',
    controller: 'pytanie4Ctrl'
  })

  .state('pytanie5', {
    url: '/page10',
    templateUrl: 'templates/pytanie5.html',
    controller: 'pytanie5Ctrl'
  })

  .state('wygrana', {
    url: '/page11',
    templateUrl: 'templates/wygrana.html',
    controller: 'wygranaCtrl'
  })

$urlRouterProvider.otherwise('/page2')

  

});